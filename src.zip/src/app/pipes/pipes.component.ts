import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipes',
  templateUrl: './pipes.component.html',
  styleUrls: ['./pipes.component.css']
})
export class PipesComponent implements OnInit {
  
  name:string="demo txt";
  DOB:Date=new Date();
  amount:number=23000;

  value:number=20;
  constructor() { }

  ngOnInit(): void {
  }

}
