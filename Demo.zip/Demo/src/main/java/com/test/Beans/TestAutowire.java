package com.test.Beans;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.test.Beans.Employee;

public class TestAutowire  {
    public static void main(String[] args) {

        ApplicationContext context =   new ClassPathXmlApplicationContext("autowire.xml");

                Employee employee = (Employee) context.getBean ("employee");

        System.out.println(employee.getFullName());

        System.out.println(employee.getDepartmentBean().getName());
    }
}
